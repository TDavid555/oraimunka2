const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'filmek'
});

// GET - összes film lekérése
app.get('/filmek', (req, res) => {
    connection.query('SELECT * FROM filmek', (err, results) => {
        if (err) return res.status(500).send('Hiba történt: ' + err);
        res.json(results);
    });
});

// POST - új film hozzáadása
app.post('/filmek', (req, res) => {
    const { cim, hossz } = req.body;
    connection.query('INSERT INTO filmek (cim, hossz) VALUES (?, ?)', [cim, hossz], (err) => {
        if (err) return res.status(500).send('Hiba történt: ' + err);
        res.send('Sikeres beszúrás');
    });
});

// PUT - film frissítése cím alapján
app.put('/filmek/:cim', (req, res) => {
    const { cim } = req.params;
    const { cim: ujCim, hossz: ujHossz } = req.body;

    const values = [];
    let query = 'UPDATE filmek SET ';
    if (ujCim) {
        query += 'cim = ?';
        values.push(ujCim);
    }
    if (ujHossz) {
        if (values.length > 0) query += ', ';
        query += 'hossz = ?';
        values.push(ujHossz);
    }
    query += ' WHERE cim = ?';
    values.push(cim);

    connection.query(query, values, (err, result) => {
        if (err) return res.status(500).json({ error: err });
        res.send('Frissítve');
    });
});

// DELETE - film törlése cím alapján
app.delete('/filmek/:cim', (req, res) => {
    const { cim } = req.params;
    connection.query('DELETE FROM filmek WHERE cim = ?', [cim], (err, result) => {
        if (err) return res.status(500).json({ error: err });
        res.send('Törölve');
    });
});

app.listen(3000, () => {
    console.log('Szerver fut a http://localhost:3000 címen');
});
