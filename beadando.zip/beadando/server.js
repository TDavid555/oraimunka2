const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(bodyParser.urlencoded({ extended: true }));

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'filmek'
});

// CRUD műveletek
app.post('/add', (req, res) => {
    const { cim, hossz } = req.body;
    connection.query('INSERT INTO filmek (cim, hossz) VALUES (?, ?)', [cim, hossz], (err) => {
        if (err) return res.send('Hiba történt: ' + err);
        res.send('Sikeres beszúrás');
    });
});

app.get('/products', (req, res) => {
    connection.query('SELECT * FROM filmek', (err, results) => {
        if (err) return res.send('Hiba történt: ' + err);
        res.json(results);
    });
});

app.post('/update', (req, res) => {
    const { cim, hossz } = req.body;
    connection.query('UPDATE filmek SET hossz = ? WHERE cim = ?', [hossz, cim], (err) => {
        if (err) return res.send('Hiba történt: ' + err);
        res.send('Sikeres módosítás');
    });
});

app.post('/delete', (req, res) => {
    const { id } = req.body;
    connection.query('DELETE FROM filmek WHERE cim = ?', [cim], (err) => {
        if (err) return res.send('Hiba történt: ' + err);
        res.send('Sikeres törlés');
    });
});

app.listen(3000, () => {
    console.log('Szerver fut a http://localhost:3000 címen');
});