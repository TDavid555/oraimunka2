document.addEventListener('DOMContentLoaded', () => {
    const itemList = document.getElementById('item-list');
    const form = document.getElementById('add-item-form');
    const itemName = document.getElementById('item-cim');
    const itemPrice = document.getElementById('item-hossz');

    const updateId = document.getElementById('update-id');
    const updateName = document.getElementById('update-cim');
    const updatePrice = document.getElementById('update-hossz');
    const updateButton = document.getElementById('update-item');

    const deleteId = document.getElementById('delete-id');
    const deleteButton = document.getElementById('delete-item');

    function getItems() {
        fetch('http://localhost:3000/filmek')
            .then(response => response.json())
            .then(data => {
                itemList.innerHTML = '';
                data.forEach(item => {
                    const li = document.createElement('li');
                    li.textContent = `${item.id}: ${item.cim} - ${item.hossz} Ft`;
                    itemList.appendChild(li);
                });
            })
            .catch(error => console.error('Hiba:', error));
    }

    form.addEventListener('submit', (e) => {
        e.preventDefault();
        const newItem = {
            cim: itemCim.value,
            hossz: Number(itemHossz.value)
        };
        fetch('http://localhost:3000/filmek', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(newItem)
        })
            .then(() => {
                itemCim.value = '';
                itemHossz.value = '';
                getItems();
            })
            .catch(error => console.error('Hiba:', error));
    });

    updateButton.addEventListener('click', () => {
        const updatedItem = {
            cim: updateCim.value,
            hossz: Number(updateHossz.value)
        };
        fetch(`http://localhost:3000/filmek/${updateId.value}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(updatedItem)
        })
            .then(() => {
                updateId.value = '';
                updateCim.value = '';
                updateHossz.value = '';
                getItems();
            })
            .catch(error => console.error('Hiba:', error));
    });

    deleteButton.addEventListener('click', () => {
        fetch(`http://localhost:3000/items/${deleteId.value}`, {
            method: 'DELETE'
        })
            .then(() => {
                deleteId.value = '';
                getItems();
            })
            .catch(error => console.error('Hiba:', error));
    });

    getItems();
});