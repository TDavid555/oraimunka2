document.addEventListener('DOMContentLoaded', () => {
    const itemList = document.getElementById('item-list');
    const addItemForm = document.getElementById('add-item-form');
    const updateButton = document.getElementById('update-item');
    const deleteButton = document.getElementById('delete-item');

    function fetchItems() {
        fetch('http://localhost:3000/filmek')
            .then(res => res.json())
            .then(data => {
                const tableBody = document.getElementById('film-table-body');
                tableBody.innerHTML = '';
    
                data.forEach(item => {
                    const row = document.createElement('tr');
    
                    const idCell = document.createElement('td');
                    idCell.textContent = item.id;
    
                    const cimCell = document.createElement('td');
                    cimCell.textContent = item.cim;
    
                    const hosszCell = document.createElement('td');
                    hosszCell.textContent = item.hossz;
    
                    row.appendChild(idCell);
                    row.appendChild(cimCell);
                    row.appendChild(hosszCell);
    
                    tableBody.appendChild(row);
                });
            });
    }

    fetchItems();

    addItemForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const cim = document.getElementById('item-cim').value;
        const hossz = document.getElementById('item-hossz').value;

        fetch('http://localhost:3000/filmek', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ cim, hossz })
        })
        .then(() => {
            fetchItems();
            addItemForm.reset();
        });
    });

    updateButton.addEventListener('click', () => {
        const cim = document.getElementById('update-id').value;
        const updateCim = document.getElementById('update-cim').value;
        const updateHossz = document.getElementById('update-hossz').value;

        fetch(`http://localhost:3000/filmek/${encodeURIComponent(cim)}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                cim: updateCim || null,
                hossz: updateHossz || null
            })
        })
        .then(() => {
            fetchItems();
            document.getElementById('update-id').value = '';
            document.getElementById('update-cim').value = '';
            document.getElementById('update-hossz').value = '';
        });
    });

    deleteButton.addEventListener('click', () => {
        const cim = document.getElementById('delete-id').value;

        fetch(`http://localhost:3000/filmek/${encodeURIComponent(cim)}`, {
            method: 'DELETE'
        })
        .then(() => {
            fetchItems();
            document.getElementById('delete-id').value = '';
        });
    });
});
