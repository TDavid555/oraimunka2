﻿using System;
using System.Linq;
using System.Windows.Forms;
using Firebase.Database;
using Firebase.Database.Query;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Diagnostics.Eventing.Reader;

namespace _0304
{
    public partial class Form1 : Form
    {
        private static FirebaseClient adatbazis;

        public Form1()
        {
            string firebase = "https://film-e77e0-default-rtdb.firebaseio.com/";
            adatbazis = new FirebaseClient(firebase);
            InitializeComponent();
        }

        private async void Form1_Load(object sender, EventArgs e)
        {
            var kedvenc = new { ev = 1981, ertekeles = 6.5, koltseg = 500000, munkaorak = 100, bevetel = 3000000 };
            var top1_1981 = new { ev = 1981, ertekeles = 8.4, koltseg = 3000000, munkaorak = 400, bevetel = 5000000};

            await adatbazis.Child("Filmek").Child("Kedvenc").Child("Aranyeső Yuccában").PutAsync(kedvenc);
            await adatbazis.Child("Filmek").Child("Top1_1981").Child("Az elveszett frigyláda fosztogatói").PutAsync(top1_1981);

            await Osszehasonlitas();
        }

        private async Task Osszehasonlitas()
        {
            var kedvenc = (await adatbazis.Child("Filmek").Child("Kedvenc").Child("Aranyeső Yuccában").OnceSingleAsync<dynamic>());
            var top1 = (await adatbazis.Child("Filmek").Child("Top1_1981").Child("Az elveszett frigyláda fosztogatói").OnceSingleAsync<dynamic>());

            string eredmeny = "";

            if (kedvenc.ertekeles > top1.ertekeles)
            {
                eredmeny += "Az Aranyeső Yuccában jobb értékelést kapott, mint Az elveszett frigyláda fosztogatói.";
                label6.Text = ">";
            }
            else
            {
                eredmeny += "Az elveszett frigyláda fosztogatói jobb értékelést kapott, mint az Aranyeső Yuccában.\n";
                label6.Text = "<";
            }

            if (kedvenc.dijak > top1.dijak)
            {
                eredmeny += "Aranyeső Yuccában több díjat nyert.\n";
                label7.Text = ">";
            }
            else
            {
                eredmeny += "Az elveszett frigyláda fosztogatói több díjat nyert.\n";
                label7.Text = "<";
            }

            if ((kedvenc.bevetel - kedvenc.koltseg) > (top1.bevetel - top1.koltseg))
            {
                eredmeny += "Aranyeső Yuccában nyereségesebb volt kiadásokat nézve.\n";
                label8.Text = ">";
            }
            else
            {
                eredmeny += "Az elveszett frigyláda fosztogatói nyereségesebb volt a kiadásokat nézve.\n";
                label8.Text = "<";
            }

            if (kedvenc.bevetel/kedvenc.munkaorak > top1.bevetel/top1.munkaorak)
            {
                eredmeny += "Aranyeső Yuccában nyereségesebb volt a munkaórák számát nézve.";
                label12.Text = ">";
            }
            else
            {
                eredmeny += "Az elveszett frigyláda fosztogatóit nyereségesebb volt a munkaórák számát nézve.";
                label12.Text = "<";
            }



            label10.Text = eredmeny;
        }
    }
}
