﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Firebase.Database;
using Firebase.Database.Query;

namespace _0304
{
    public partial class Form1 : Form
    {
        private static FirebaseClient adatbazis;


        public Form1()
        {
            string firebase = "https://film-e77e0-default-rtdb.firebaseio.com/";
            adatbazis = new FirebaseClient(firebase);
            InitializeComponent();
        }

        private async void Form1_Load(object sender, EventArgs e)
        {
            var kedvenc = new { ev = 1981, ertekeles = 6.5, díjak = 1, kritikai_velemeny = 3 };
            var top1_1981 = new { ev = 1981, ertekeles = 8.4, díjak = 38, kritikai_velemeny = 222};

            await adatbazis.Child("Filmek").Child("Kedvenc").Child("Aranyeső Yuccában").PutAsync(kedvenc);
            await adatbazis.Child("Filmek").Child("Top1_1981").Child("Az elveszett frigyláda fosztogatói").PutAsync(top1_1981);



        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
}
