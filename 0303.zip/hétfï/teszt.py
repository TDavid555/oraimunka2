import unittest
from regiszt import Jatekok

class TestMuveletek(unittest.TestCase):

    def setUp(self):
        #Játékok létrehozása
        self.jatekok = {
            "Cyberpunk 2077": 23000,
            "The Witcher 3": 16000,
            "Elden Ring": 27000,
            "GTA V": 12000,
            "Red Dead Redemption 2": 20000,
            "Minecraft": 9750,
            "Doom Eternal": 19500,
            "Horizon Zero Dawn": 17500,
            "God of War": 23500,
            "Assassin's Creed Valhalla": 27330
        }
        self.math = Jatekok()

    def test_atlag_ar(self):
        #Átlagár tesztelése
        vart = sum(self.jatekok.values()) / len(self.jatekok)
        self.assertEqual(self.math.atlag_ar(), vart)

    def test_legolcsobb_jatek(self):
        #Legolcsóbb tesztelése
        legolcsobb, ar = self.math.legolcsobb_jatek()
        self.assertEqual(legolcsobb, "Minecraft")
        self.assertEqual(ar, 9750)

    def test_legdragabb_jatek(self):
        #Legdrágább tesztelése
        legdragabb, ar = self.math.legdragabb_jatek()
        self.assertEqual(legdragabb, "Assassin's Creed Valhalla")
        self.assertEqual(ar, 27330)

    def test_kereses_jatek_azonos_ar(self):
        #Játék keresés tesztelése - ha ugyanaz az ár található
        ar = self.math.jatek_kereses("Cyberpunk 2077")
        self.assertEqual(ar, 23000)

    def test_arok_hasonlitas(self):
        #A legdrágább játék ára > mint a legolcsóbbé
        legolcsobb, ar_olcsobb = self.math.legolcsobb_jatek()
        legdragabb, ar_dragabb = self.math.legdragabb_jatek()
        self.assertGreater(ar_dragabb, ar_olcsobb)



if __name__ == "__main__":
    unittest.main()
