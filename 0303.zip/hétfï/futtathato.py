#Bejelentkezés - email és jelszó ellenőrzése
def bejelentkezes(email, jelszo):
    print("\nBejelentkezés\n")
    while True:
        emailbe = input("Email: ")
        jelszobe = input("Jelszó: ")
        if emailbe == email and jelszobe == jelszo:
            print("Sikeres bejelentkezés\n")
            return True
        else:
            print("Email vagy jelszó helytelen")


# Játékok listája
jatekok = {
    "Cyberpunk 2077": 23000,
    "The Witcher 3": 16000,
    "Elden Ring": 27000,
    "GTA V": 12000,
    "Red Dead Redemption 2": 20000,
    "Minecraft": 9750,
    "Doom Eternal": 19500,
    "Horizon Zero Dawn": 17500,
    "God of War": 23500,
    "Assassin's Creed Valhalla": 27330
}

#felhasználó által kért játék megkeresése
def jatek_kereses():
    jatek_nev = input("Melyik játékot keresed? ")
    return jatekok.get(jatek_nev)

#játékok árának átlaga
def atlagar():
    return sum(jatekok.values()) / len(jatekok)

#legolcsóbb játék megkeresése
def legolcsobb_jatek():
    min_ar = 100000
    min_jatek = ""

    for jatek, ar in jatekok.items():
        if ar < min_ar:
            min_ar = ar
            min_jatek = jatek

    return min_jatek, min_ar

#legdrágább játék megkeresése
def legdragabb_jatek():
    max_ar = -1
    max_jatek = ""

    for jatek, ar in jatekok.items():
        if ar > max_ar:
            max_ar = ar
            max_jatek = jatek

    return max_jatek, max_ar


#futtatás
print("Regisztráció\n")

emailok = False
nagybetuok = False
szamok = False
nyolc = False
jelszook = False

#Regisztráció - email és jelszó ellenőrzése, megfelel-e
while emailok == False or jelszook == False:
    
    emailbeker = input("Email: ")
    jelszobeker = input("Jelszó: ")
    if "@" in emailbeker and "." in emailbeker:
        emailok = True
    else:
        emailok = False

    nagybetuok = any(x.isupper() for x in jelszobeker)
    szamok = any(x.isdigit() for x in jelszobeker)
    nyolc = len(jelszobeker) >= 8
    spec_karakter = any(c in jelszobeker for c in "#!$&*")
    
    if nyolc and nagybetuok and szamok and spec_karakter:
        jelszook = True

    
    if emailok and jelszook:
        email = emailbeker
        jelszo = jelszobeker
        print("Sikeres regisztráció!")
        break
    else:
        print("Nem megfelelő email vagy jelszó")


if bejelentkezes(email, jelszo):
    keresett_ar = jatek_kereses()
    if keresett_ar:
        print(f"A keresett játék ára: {keresett_ar} Ft")
    else:
        print("Ez a játék nem található")

    print(f"A játékok átlagára: {atlagar()} Ft")

    olcsobb = legolcsobb_jatek()
    print(f"A legolcsóbb játék: {olcsobb[0]}, ára: {olcsobb[1]} Ft")

    dragabb = legdragabb_jatek()
    print(f"A legdrágább játék: {dragabb[0]}, ára: {dragabb[1]} Ft")

