class Jatekok:

    def __init__(self):
        self.jatekok = {
            "Cyberpunk 2077": 23000,
            "The Witcher 3": 16000,
            "Elden Ring": 27000,
            "GTA V": 12000,
            "Red Dead Redemption 2": 20000,
            "Minecraft": 9750,
            "Doom Eternal": 19500,
            "Horizon Zero Dawn": 17500,
            "God of War": 23500,
            "Assassin's Creed Valhalla": 27330
        }

    #játékok árának átlaga
    def atlag_ar(self):
        return sum(self.jatekok.values()) / len(self.jatekok)

    def legolcsobb_jatek(self):
        #A legolcsóbb megkeresése
        min_jatek = list(self.jatekok.keys())[0]
        min_ar = self.jatekok[min_jatek]
        
        for jatek, ar in self.jatekok.items():
            if ar < min_ar:
                min_ar = ar
                min_jatek = jatek
        return min_jatek, min_ar

    def legdragabb_jatek(self):
        #A legdrágább megkeresése
        max_jatek = list(self.jatekok.keys())[0]
        max_ar = self.jatekok[max_jatek]
        
        for jatek, ar in self.jatekok.items():
            if ar > max_ar:
                max_ar = ar
                max_jatek = jatek
        return max_jatek, max_ar

    def jatek_kereses(self, jatek_nev):
        return self.jatekok.get(jatek_nev, None)
