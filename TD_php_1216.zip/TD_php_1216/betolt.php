<?php
include "kapcsolat.php";

function betolt(){
global $conn;
$leker = mysqli_query($conn, "SELECT SUM(`db`) FROM `kivansagok`");
$eredmeny = $leker;

echo $eredmeny;

}

?>