<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <title>Jezuska</title>
</head>
<body>

<?php

include 'kapcsolat.php';

$tabla = "CREATE TABLE IF NOT EXISTS kivansagok(
    id INT(100) PRIMARY KEY AUTO_INCREMENT,
    nev VARCHAR(100) NOT NULL,
    kivansag VARCHAR(100) NOT NULL,
    db INT(100) NOT NULL,
    email VARCHAR(100) NOT NULL)";


$prepare = mysqli_prepare($conn, $tabla);
mysqli_stmt_execute($prepare);


if(ellenorzes()){
    feltoltes();
}

function ellenorzes(){
    $nev = isset($_POST["nev"]) && !empty($_POST["nev"]);
    $kivansag = isset($_POST["kivansag"]) && !empty($_POST["kivansag"]);
    $darab = isset($_POST["darab"]) && !empty($_POST["darab"]);
    $email = isset($_POST["email"]) && !empty($_POST["email"]);

    return $nev & $kivansag & $darab & $email;
}


function feltoltes(){
    global $conn;
    $nev = $_REQUEST["nev"];
    $kivansag = $_REQUEST["kivansag"];
    $darab = $_REQUEST["darab"];
    $email = $_REQUEST["email"];

    $feltolt = "INSERT INTO `kivansagok` (`nev`, `kivansag`, `db`, `email`) VALUES ('$nev', '$kivansag', '$darab', '$email');";

    $prepare2 = mysqli_prepare($conn, $feltolt);
    mysqli_stmt_execute($prepare2);

}


?>
<a href="index.php"><button class="btn btn-primary">Főoldal</button></a>


</body>
</html>