<?php

$host = '127.0.0.1';
$username = 'root';
$passw = '';
$dbname = '1216';

$conn = mysqli_connect($host, $username, $passw, $dbname);

mysqli_set_charset($conn, 'utf8');

?>