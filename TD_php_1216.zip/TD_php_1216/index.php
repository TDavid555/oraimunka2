<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <title>Jezuska</title>
</head>
<body class="bg-info">
    

<!--Insert-->
<div class="container mt-4 p-4 w-50">
    <h2 style="text-align: center;">Kívánság küldése</h2>
    <form action="insert.php" method="post">
        <div class="row">
        <label for="nev">Név</label>
        <input type="text" name="nev" placeholder="Keresztnév">
        </div>

        <div class="row">
        <label for="kivansag">Kívánság</label>
        <input type="text" name="kivansag" placeholder="Kívánság">
        </div>

        <div class="row">
        <label for="darab">Mennyiség</label>
        <input type="number" name="darab" placeholder="Mennyiség">
        </div>

        <div class="row">
        <label for="email">Email</label>
        <input type="email" name="email" placeholder="Email cím">
        </div> <br>

        <div class="row">
            <input type="submit" class="btn btn-warning" value="Küldés">
        </div>
    </form>
</div>
<br>



<!--Delete-->
<div class="container mt-4 p-4 w-50">
    <h2 style="text-align: center;">Kívánságok törlése</h2>
    <form action="delete.php" method="get">

        <div class="row">
        <label for="nev">Név</label>
        <input type="text" name="nev" placeholder="Keresztnév">
        </div> <br>

        <div class="row">
            <input type="submit" class="btn btn-warning" value="Törlés">
        </div>

    </form>
</div>




<!--Update-->
<div class="container mt-4 p-4 w-50">
    <h2 style="text-align: center;">Mennyiség módosítása</h2>
    <form action="update.php" method="get">
        <div class="row">
        <label for="kivansag">Kívánság</label>
        <input type="text" name="kivansag" placeholder="Kívánság">
        </div>

        <div class="row">
        <label for="darab">Új mennyiség</label>
        <input type="number" name="darab" placeholder="Mennyiség">
        </div> <br>

        <div class="row">
            <input type="submit" class="btn btn-warning" value="Módosít">
        </div>

    </form>
</div>





<div class="container mt-4 p-4 w-50">

    <?php
        //include "betolt.php";
        //require betolt();
    ?>

</div>


</body>
</html>